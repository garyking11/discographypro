This plug-in was intended to be used to display feature stories on a home page of a website, but can be used for any reason and is highly customizable. It will always display three images at the same time, with all the rest hidden behind the center image.

Modified to handle movingToCenter callback (start of moving a feature to center)

Dual-licensed under the GPL or MIT licenses.

CONTACT INFORMATION:

BRIAN OSBORNE
brian@bkosborne.com
http://www.bkosborne.com/jquery-feature-carousel
